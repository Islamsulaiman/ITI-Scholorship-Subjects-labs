const currentAudio = document.querySelector('.my-music') 
const repeatBtn = document.querySelector('.btn-two') 
const playBtn = document.querySelector('.btn-three')
const shuffleAudio = document.querySelector('.btn-one')
const divaudioone = document.querySelector('.audio-one')
const divaudiotwo = document.querySelector('.audio-two')
const divaudiothree = document.querySelector('.audio-three')
let currIndex = 0;
const audioSrc = [
    './Audio/Ahzee - Go Gyal (lyrics).mp3',
    './Audio/Calvin Harris, Dua Lipa - One Kiss (Official Video).mp3',
    './Audio/Khaled - Cest La Vie.mp3'
];

LoadAllEvents()
function LoadAllEvents(){
    repeatBtn.addEventListener('click',restartAudio)
    playBtn.addEventListener('click',playAudio)
    shuffleAudio.addEventListener('click',shuffle)
    divaudioone.addEventListener('mouseover',playAudioOne)
    divaudiotwo.addEventListener('mouseover',playAudiotwo)
    divaudiothree.addEventListener('mouseover',playAudiothree)
}
function restartAudio(){
    currentAudio.currentTime = 0;
}
function playAudio(){
    currentAudio.play()
}
function shuffle(){
    //var randomnumber = Math.floor(Math.random() * (maximum - minimum + 1)) + minimum;
    let random = Math.floor(Math.random()*(2-0+1) + 0)
    currentAudio.setAttribute('src',audioSrc[random])
}
function playAudioOne(){
    currentAudio.setAttribute('src',audioSrc[0])
    currentAudio.play()
}
function playAudiotwo(){
    currentAudio.setAttribute('src',audioSrc[1])
    currentAudio.play()
}
function playAudiothree(){
    currentAudio.setAttribute('src',audioSrc[2])
    currentAudio.play()
}