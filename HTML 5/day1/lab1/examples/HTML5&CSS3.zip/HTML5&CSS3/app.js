const hidebtn = document.querySelector('.btn')
const fig = document.querySelector('.main-figure')
const nameInput = document.querySelector('.input-name')
const emailInput = document.querySelector('.input-email')
const passwordInput = document.querySelector('.input-password')
const ageInput = document.querySelector('.input-age')
const salary = document.querySelector('.input-salary')
let check=false;


LoadAllEvents()

function LoadAllEvents(){
    // hidebtn.addEventListener('click',hideshow)
    nameInput.addEventListener('keyup',checkName)
    emailInput.addEventListener('keyup',checkEmail)
    passwordInput.addEventListener('keyup',checkPassword)
    ageInput.addEventListener('keyup',checkAge)
    salary.addEventListener('mouseup',outputSalary)
}
function hideshow(){
    if(check == false){
        fig.style.display='none'
        check=true
    }else{
        fig.style.display='block'
        
    }
}
function checkName(e){
    const er = document.querySelector('.error-name')
    let input = e.target.value
    if(/[0-9]/.test(input)){
        er.innerHTML = '<p>Do not enter number</p>'
    }else{
        er.innerHTML=''
    }
}
function checkEmail(e){
    const er = document.querySelector('.error-email')
    let input = e.target.value
    er.innerHTML=''
    if(/(@gmail)|(@yahoo)|(@hotmail)/.test(input)){
        er.innerHTML=''
    }else{
        
        er.innerHTML = '<p>check your</p>'
    }
}
function checkPassword(e){
    const er = document.querySelector('.error-password')
    let input = e.target.value
    if(input.length > 8){
        er.innerHTML = '<p>password exceeded 8 characters</p>'
    }else{
        er.innerHTML=''
    }
}
function checkAge(e){
    const er = document.querySelector('.error-age')
    let input = e.target.value
    
    if(input==''){
        er.innerHTML=''
    }
    else if(input < 21){
        er.innerHTML = '<p>Enta 3ail so8aiar your age must be greater than 21</p>'
    }else{
        er.innerHTML=''
    }
}
function outputSalary(e){
    const er = document.querySelector('.output-salary')
    let input = e.target.value
    er.innerHTML=input
}